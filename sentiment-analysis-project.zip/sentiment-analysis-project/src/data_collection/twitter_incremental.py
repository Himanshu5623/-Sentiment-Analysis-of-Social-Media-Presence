import os, json, time, pandas as pd
from dotenv import load_dotenv
from tweepy import Client, Paginator

load_dotenv()
BEARER = os.getenv("TWITTER_BEARER_TOKEN")
client = Client(bearer_token=BEARER, wait_on_rate_limit=True)

SINCE_FILE = "data/raw/twitter/last_ids.json"

def read_since(query):
    if os.path.exists(SINCE_FILE):
        try:
            d = json.load(open(SINCE_FILE))
            return d.get(query)
        except:
            return None
    return None

def write_since(query, since_id):
    d = {}
    if os.path.exists(SINCE_FILE):
        try:
            d = json.load(open(SINCE_FILE))
        except:
            d = {}
    d[query] = since_id
    json.dump(d, open(SINCE_FILE,"w"))

def fetch_tweets_incremental(query, max_tweets=100, lang='en'):
    since_id = read_since(query)
    tweet_fields = ["id","text","created_at","lang","public_metrics","author_id"]
    paginator = Paginator(
        client.search_recent_tweets,
        query=f"{query} -is:retweet lang:{lang}",
        tweet_fields=tweet_fields,
        max_results=10,   # Keep it small to avoid rate limit
        since_id=since_id
    )
    rows=[]; count=0; newest=None
    for page in paginator:
        if page.data is None:
            continue
        for t in page.data:
            if newest is None or int(t.id) > int(newest):
                newest = t.id
            pm = t.public_metrics or {}
            rows.append({
                "id": t.id,
                "text": t.text,
                "created_at": t.created_at.isoformat() if t.created_at else None,
                "lang": t.lang,
                "author_id": t.author_id,
                "retweet_count": pm.get("retweet_count"),
                "reply_count": pm.get("reply_count"),
                "like_count": pm.get("like_count"),
                "quote_count": pm.get("quote_count")
            })
            count += 1
            if count >= max_tweets:
                break
        if count >= max_tweets:
            break
        time.sleep(1)
    df = pd.DataFrame(rows)
    if newest:
        write_since(query, newest)
    return df
