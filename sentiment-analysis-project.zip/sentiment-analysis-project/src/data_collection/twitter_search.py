#!/usr/bin/env python3
"""Simple Twitter (X) recent-search collector using Tweepy v4 (Client)."""
import os, time, argparse
from dotenv import load_dotenv
import pandas as pd
from tweepy import Client, Paginator

load_dotenv()
BEARER = os.getenv("TWITTER_BEARER_TOKEN")
if not BEARER:
    raise RuntimeError("Set TWITTER_BEARER_TOKEN in .env")

client = Client(bearer_token=BEARER, wait_on_rate_limit=True)

def fetch_tweets(query, max_tweets=200, lang='en'):
    tweet_fields = ["id","text","created_at","lang","public_metrics","author_id"]
    expansions = ["author_id"]
    users_fields = ["username","name"]
    paginator = Paginator(
        client.search_recent_tweets,
        query=f"{query} -is:retweet lang:{lang}",
        tweet_fields=tweet_fields,
        user_fields=users_fields,
        expansions=expansions,
        max_results=100
    )

    rows = []
    count = 0
    for page in paginator:
        if page.data is None:
            continue
        for t in page.data:
            pm = t.public_metrics or {}
            rows.append({
                "id": t.id,
                "text": t.text,
                "created_at": t.created_at.isoformat() if t.created_at else None,
                "lang": t.lang,
                "author_id": t.author_id,
                "retweet_count": pm.get("retweet_count"),
                "reply_count": pm.get("reply_count"),
                "like_count": pm.get("like_count"),
                "quote_count": pm.get("quote_count"),
            })
            count += 1
            if count >= max_tweets:
                break
        if count >= max_tweets:
            break
        time.sleep(1)  # polite pacing
    return pd.DataFrame(rows)

def save_df(df, prefix="twitter"):
    ts = pd.Timestamp.now().strftime("%Y%m%d_%H%M%S")
    path = os.path.join(os.path.dirname(__file__), "../../data/raw/twitter", f"{prefix}_{ts}.parquet")
    df.to_parquet(path, index=False)
    return path

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--query", "-q", type=str, default="python", help="Search query (quotes allowed)")
    parser.add_argument("--max", "-m", type=int, default=100, help="Max tweets to fetch")
    args = parser.parse_args()
    print("Running query:", args.query, "max:", args.max)
    df = fetch_tweets(args.query, max_tweets=args.max)
    if df.empty:
        print("No tweets fetched.")
    else:
        out = save_df(df, prefix="twitter")
        print("Saved", out)
