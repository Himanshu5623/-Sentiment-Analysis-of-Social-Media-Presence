#!/usr/bin/env python3
"""
Usage:
 python src/data_collection/youtube_comments.py --video VIDEO_ID --max 1000
Or search by playlist etc. This script fetches comments for a video and saves parquet.
"""
import os, argparse, pandas as pd, time
from googleapiclient.discovery import build
from dotenv import load_dotenv

load_dotenv()
API_KEY = os.getenv("YOUTUBE_API_KEY")
if not API_KEY:
    raise SystemExit("YOUTUBE_API_KEY not found in .env")

def fetch_comments(video_id, max_comments=500):
    youtube = build("youtube", "v3", developerKey=API_KEY, cache_discovery=False)
    comments = []
    next_token = None
    fetched = 0
    while True:
        res = youtube.commentThreads().list(
            part="snippet,replies",
            videoId=video_id,
            maxResults=100,
            pageToken=next_token,
            textFormat="plainText"
        ).execute()
        for item in res.get("items", []):
            s = item["snippet"]["topLevelComment"]["snippet"]
            comments.append({
                "id": item["id"],
                "author": s.get("authorDisplayName"),
                "text": s.get("textDisplay"),
                "like_count": s.get("likeCount"),
                "published_at": s.get("publishedAt"),
                "video_id": video_id
            })
            fetched += 1
            if fetched >= max_comments:
                break
        next_token = res.get("nextPageToken")
        if not next_token or fetched >= max_comments:
            break
        time.sleep(1)  # polite pacing
    return pd.DataFrame(comments)

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--video", "-v", required=True, help="YouTube video id")
    p.add_argument("--max", "-m", default=500, type=int)
    args = p.parse_args()
    df = fetch_comments(args.video, max_comments=args.max)
    if df.empty:
        print("No comments fetched.")
    else:
        os.makedirs("data/raw/youtube", exist_ok=True)
        path = f"data/raw/youtube/youtube_comments_{args.video}_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}.parquet"
        df.to_parquet(path, index=False)
        print("Saved", path)
