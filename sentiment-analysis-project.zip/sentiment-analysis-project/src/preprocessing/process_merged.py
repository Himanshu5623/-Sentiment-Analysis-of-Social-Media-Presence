import pandas as pd, re, os, glob
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
nltk.download('punkt', quiet=True)
nltk.download('stopwords', quiet=True)
stop_words = set(stopwords.words("english"))

def clean_text(text):
    if not isinstance(text, str):
        return ""
    t = text.lower()
    t = re.sub(r'http\\S+|www\\S+','', t)
    t = re.sub(r'@\\w+','', t)
    t = re.sub(r'[^a-z0-9\\s]',' ', t)
    toks = word_tokenize(t)
    toks = [w for w in toks if w not in stop_words and len(w)>1]
    return " ".join(toks)

files = sorted(glob.glob("data/raw/merged/twitter_raw_merged.parquet"))
if not files:
    print("No merged raw file found.")
else:
    df = pd.read_parquet(files[-1])
    df['clean'] = df['text'].astype(str).apply(clean_text)
    os.makedirs("data/processed", exist_ok=True)
    out = f"data/processed/twitter_processed_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}.parquet"
    df.to_parquet(out, index=False)
    print("Processed and saved to", out)
