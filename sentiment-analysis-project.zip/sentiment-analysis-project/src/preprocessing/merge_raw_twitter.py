import glob, pandas as pd, os
files = sorted(glob.glob("data/raw/twitter/*.parquet"))
dfs=[]
for f in files:
    try:
        dfs.append(pd.read_parquet(f))
    except Exception as e:
        print("Failed to read", f, e)
if not dfs:
    print("No files to merge")
else:
    df = pd.concat(dfs, ignore_index=True)
    df.drop_duplicates(subset=['id'], inplace=True)
    os.makedirs("data/raw/merged", exist_ok=True)
    out = "data/raw/merged/twitter_raw_merged.parquet"
    df.to_parquet(out, index=False)
    print("Merged rows:", len(df))
    print("Saved to", out)
