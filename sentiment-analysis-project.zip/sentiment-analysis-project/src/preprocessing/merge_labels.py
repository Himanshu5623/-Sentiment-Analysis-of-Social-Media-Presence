import pandas as pd
import glob, os

# Find latest processed file
proc_files = sorted(glob.glob("data/processed/twitter_processed_*.parquet"))
if not proc_files:
    print("No processed files found.")
    raise SystemExit(1)

proc = proc_files[-1]
df_proc = pd.read_parquet(proc)

# Load labeled CSV
lbl = "data/labels/labeled_tweets.csv"
if not os.path.exists(lbl):
    print("Label file not found:", lbl)
    raise SystemExit(1)

df_lbl = pd.read_csv(lbl)

print("Processed rows:", len(df_proc))
print("Labeled rows:", len(df_lbl))

# Merge on 'id'
df_merged = df_proc.merge(df_lbl[['id', 'label']], on='id', how='inner')

if df_merged.empty:
    print("No matching IDs between processed data and labels.")
    raise SystemExit(1)

# Save final training dataset
os.makedirs("data/processed", exist_ok=True)
out = "data/processed/train_dataset.parquet"
df_merged.to_parquet(out, index=False)

print("Training dataset saved:", out)
print("Merged rows:", len(df_merged))
print("Label distribution:\n", df_merged['label'].value_counts())
