#!/usr/bin/env python3
import glob, os, re, pandas as pd
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

# Download required NLTK components silently
nltk.download('punkt', quiet=True)
nltk.download('stopwords', quiet=True)
stop_words = set(stopwords.words("english"))

def clean_text(text):
    if not isinstance(text, str):
        return ""
    t = text.lower()
    t = re.sub(r'http\\S+|www\\S+', '', t)
    t = re.sub(r'@\\w+', '', t)
    t = re.sub(r'[^a-z0-9\\s]', ' ', t)
    toks = word_tokenize(t)
    toks = [w for w in toks if w not in stop_words and len(w) > 1]
    return " ".join(toks)

files = sorted(glob.glob("data/raw/youtube/*.parquet"))

if not files:
    print("No YouTube raw files found in data/raw/youtube/")
else:
    out_frames = []
    for f in files:
        try:
            df = pd.read_parquet(f)
            df["clean"] = df["text"].astype(str).apply(clean_text)
            out_frames.append(df)
            print("Processed:", f, "rows:", len(df))
        except Exception as e:
            print("Error processing", f, e)

    if out_frames:
        df_all = pd.concat(out_frames, ignore_index=True)
        os.makedirs("data/processed", exist_ok=True)
        out_path = f"data/processed/youtube_processed_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}.parquet"
        df_all.to_parquet(out_path, index=False)
        print("\nSaved processed YouTube file to:", out_path)
    else:
        print("No usable YouTube files processed.")
