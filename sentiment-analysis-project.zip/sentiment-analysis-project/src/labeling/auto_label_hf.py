from transformers import pipeline
import pandas as pd, glob, os

# create pipeline (will download model if missing)
clf = pipeline("sentiment-analysis", model="distilbert/distilbert-base-uncased-finetuned-sst-2-english")

files = sorted(glob.glob("data/raw/youtube/*.parquet"))
rows = []
for f in files:
    df = pd.read_parquet(f)
    for _, r in df.iterrows():
        text = str(r.get("text", ""))
        if not text.strip():
            continue
        # TF-safe snippet
        snippet = text[:400]
        try:
            res = clf(snippet)
            label = res[0]["label"].upper()
            score = float(res[0]["score"])
        except Exception as e:
            label = "NEUTRAL"
            score = 0.0
        rows.append({
            "id": r.get("id"),
            "created_at": r.get("created_at"),
            "text": text,
            "clean": text,
            "label": label,
            "score": score
        })

out = pd.DataFrame(rows)
os.makedirs("data/labels", exist_ok=True)
out.to_parquet("data/labels/youtube_auto_labeled.parquet", index=False)
print("Saved", len(out), "auto-labeled rows to data/labels/youtube_auto_labeled.parquet")
