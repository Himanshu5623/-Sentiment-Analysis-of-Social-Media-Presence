#!/usr/bin/env python3
import os, joblib, pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score

# Load training dataset
path = "data/processed/train_dataset.parquet"
if not os.path.exists(path):
    raise SystemExit(f"Training file not found: {path}")

df = pd.read_parquet(path)
df = df.dropna(subset=['clean','label'])
print("Total rows for training:", len(df))
print(df['label'].value_counts())

X = df['clean'].astype(str)
y = df['label'].astype(str)

# If possible, stratify; otherwise skip stratify for very small datasets
try:
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.4, random_state=42, stratify=y
    )
    print("Using stratified split.")
except Exception:
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.4, random_state=42
    )
    print("Stratified split failed (small dataset). Using random split.")

print("Train size:", len(X_train), "Test size:", len(X_test))
# Vectorize
vect = TfidfVectorizer(max_features=5000, ngram_range=(1,2), min_df=1)
X_train_vec = vect.fit_transform(X_train)
X_test_vec = vect.transform(X_test)

# Train with balanced class weight if multiple classes present
classes = y_train.unique()
if len(classes) > 1:
    clf = LogisticRegression(max_iter=1000)
else:
    clf = LogisticRegression(max_iter=1000)
clf.fit(X_train_vec, y_train)

# Evaluate
y_pred = clf.predict(X_test_vec)
print("Accuracy:", accuracy_score(y_test, y_pred))
print("Classification report:\n", classification_report(y_test, y_pred))

# Save model + vectorizer
os.makedirs("models", exist_ok=True)
joblib.dump(vect, "models/tfidf_vectorizer.joblib")
joblib.dump(clf, "models/logreg_sentiment.joblib")
print("Saved models:")
print(" - models/tfidf_vectorizer.joblib")
print(" - models/logreg_sentiment.joblib")
