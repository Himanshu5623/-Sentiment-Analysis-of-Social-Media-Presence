import streamlit as st
import pandas as pd
import glob

st.set_page_config(page_title="Sentiment POC", layout="wide")
st.title("Sentiment Analysis — POC Dashboard")

# load predictions
files = sorted(glob.glob("data/outputs/predictions_*.parquet"))
if not files:
    st.warning("No prediction files found. Run batch prediction first.")
    st.stop()

df = pd.read_parquet(files[-1])

st.sidebar.markdown("### Filters")
src = st.sidebar.multiselect(
    "Source",
    options=sorted(df['source'].unique()),
    default=sorted(df['source'].unique())
)

preds = st.sidebar.multiselect(
    "Predictions",
    options=sorted(df['pred'].unique()),
    default=sorted(df['pred'].unique())
)

min_conf = st.sidebar.slider("Min confidence", 0.0, 1.0, 0.0, 0.01)

df = df[
    (df['source'].isin(src)) &
    (df['pred'].isin(preds)) &
    (df['conf'] >= min_conf)
]

st.metric("Total comments", len(df))
st.bar_chart(df['pred'].value_counts())

st.markdown("## Top examples (by confidence)")
for _, r in df.sort_values("conf", ascending=False).head(50).iterrows():
    st.write(f"**{r['pred']}**  —  conf {r['conf']:.2f}  —  source: {r['source']}")
    st.write(r['text'])
    st.write("---")

