import streamlit as st
import pandas as pd
import pathlib
import glob

st.set_page_config(page_title="Sentiment POC Dashboard", layout="wide")
st.title("📊 Sentiment Analysis — POC Dashboard")

# -------------------------------------------------------
# Load latest predictions file
# -------------------------------------------------------
files = sorted(glob.glob("data/outputs/predictions_*.parquet"))
if not files:
    st.error("❌ No prediction files found. Run the batch prediction step first.")
    st.stop()

latest_file = files[-1]
st.sidebar.success(f"Loaded file:\n**{latest_file}**")

df = pd.read_parquet(latest_file)

# Ensure created_at is datetime & timezone-aware (UTC)
df["created_at"] = pd.to_datetime(df["created_at"], utc=True, errors="coerce")

# -------------------------------------------------------
# Sidebar Filters
# -------------------------------------------------------
st.sidebar.header("🔎 Filters")

# Source filter
src_options = sorted(df["source"].dropna().unique())
src_select = st.sidebar.multiselect(
    "Source",
    options=src_options,
    default=src_options
)

# Prediction filter
pred_options = sorted(df["pred"].dropna().unique())
pred_select = st.sidebar.multiselect(
    "Predictions",
    options=pred_options,
    default=pred_options
)

# Confidence filter
min_conf = st.sidebar.slider("Minimum confidence", 0.0, 1.0, 0.0, 0.01)

# -------------------------------------------------------
# Date Filter (Timezone Safe)
# -------------------------------------------------------
st.sidebar.markdown("### 📅 Date Range (UTC)")

if df["created_at"].notna().any():
    min_date = df["created_at"].min().date()
    max_date = df["created_at"].max().date()
else:
    min_date = None
    max_date = None

start_date = st.sidebar.date_input("Start Date", value=min_date)
end_date = st.sidebar.date_input("End Date", value=max_date)

# Build mask
mask = pd.Series(True, index=df.index)

# Apply source + prediction + confidence filters
mask &= df["source"].isin(src_select)
mask &= df["pred"].isin(pred_select)
mask &= df["conf"] >= min_conf

# Apply date range filter (timezone-safe)
if start_date and end_date:
    start_dt = pd.to_datetime(start_date).tz_localize("UTC")
    end_dt = (pd.to_datetime(end_date) + pd.Timedelta(days=1)).tz_localize("UTC")
    mask &= (df["created_at"] >= start_dt) & (df["created_at"] < end_dt)

df_f = df[mask].copy()

# -------------------------------------------------------
# Stats + Charts
# -------------------------------------------------------
st.metric("Total comments", len(df_f))

if len(df_f) > 0:
    st.subheader("Sentiment Distribution")
    st.bar_chart(df_f["pred"].value_counts())
else:
    st.warning("No comments match the selected filters.")

# -------------------------------------------------------
# Top Examples
# -------------------------------------------------------
st.subheader("📝 Top Examples (sorted by confidence)")

if len(df_f) == 0:
    st.info("No rows to display.")
else:
    for _, r in df_f.sort_values("conf", ascending=False).head(50).iterrows():
        st.write(f"### **{r['pred']}** — {r['conf']:.2f} confidence — *{r['source']}*")
        st.write(r["text"])
        st.write("---")


